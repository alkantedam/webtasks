<?php

$age = 15;
print "He is $age years old";

?>


He is <?= $age ?> years old


He is 
<?php
echo $age 
?> years old
